<?php
require_once __DIR__ . '/../../includes/auth.php';
$session = requireAuthAPI('ADMIN');

$id = $_GET['id'] ?? null;
if (!$id) jsonResponse(['error' => 'ID required'], 400);

$db   = getDB();
$stmt = $db->prepare("SELECT d.*, u.fullname AS owner_name, dt.name AS type_name
  FROM documents d
  JOIN users u ON u.id = d.owner_id
  JOIN document_types dt ON dt.id = d.document_type_id
  WHERE d.id = ?");
$stmt->execute([$id]);
$doc = $stmt->fetch();

if (!$doc) jsonResponse(['error' => 'Document not found'], 404);

jsonResponse($doc);
