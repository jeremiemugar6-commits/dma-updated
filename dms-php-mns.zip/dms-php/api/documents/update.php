<?php
require_once __DIR__ . '/../../includes/auth.php';
$session = requireAuthAPI('ADMIN');

$data = json_decode(file_get_contents('php://input'), true);
$db   = getDB();

$id = $data['id'] ?? null;
if (!$id) jsonResponse(['error' => 'ID required'], 400);

if (empty($data['document_type_id']) || empty($data['status']) || empty($data['location'])) {
    jsonResponse(['error' => 'document_type_id, status and location are required'], 400);
}

$stmt = $db->prepare(
    "UPDATE documents
     SET document_type_id = ?,
         status           = ?,
         location         = ?,
         expiration_date  = ?
     WHERE id = ?"
);
$stmt->execute([
    $data['document_type_id'],
    $data['status'],
    trim($data['location']),
    $data['expiration_date'] ?: null,
    $id,
]);

logAudit($session['userId'], 'DOCUMENT_MODIFIED', "Updated: " . $data['location'], $id);

jsonResponse(['success' => true]);
