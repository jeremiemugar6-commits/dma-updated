<?php
require_once __DIR__ . '/../../includes/auth.php';
$session = requireAuthAPI('ADMIN');

$data = json_decode(file_get_contents('php://input'), true);
$db   = getDB();

$required = ['document_type_id', 'owner_id', 'location'];
foreach ($required as $f) {
    if (empty($data[$f])) jsonResponse(['error' => "Field '$f' is required"], 400);
}

$id             = generateUUID();
$location       = trim($data['location']);
$docTypeId      = $data['document_type_id'];
$ownerId        = $data['owner_id'];
$expirationDate = $data['expiration_date'] ?? null;

$stmt = $db->prepare("INSERT INTO documents (id, location, document_type_id, owner_id, expiration_date, status, version)
                      VALUES (?, ?, ?, ?, ?, 'ACTIVE', 1)");
$stmt->execute([$id, $location, $docTypeId, $ownerId, $expirationDate ?: null]);

logAudit($session['userId'], 'DOCUMENT_CREATED', "Document created: $location", $id);

jsonResponse(['success' => true, 'id' => $id]);
