<?php
require_once __DIR__ . '/../../includes/auth.php';
$session = requireAuthAPI('ADMIN');

$data = json_decode(file_get_contents('php://input'), true);
$db   = getDB();
$id   = $data['id'] ?? null;
if (!$id) jsonResponse(['error' => 'ID required'], 400);

$stmt = $db->prepare("UPDATE documents SET is_deleted = 1 WHERE id = ?");
$stmt->execute([$id]);

logAudit($session['userId'], 'DOCUMENT_DELETED', 'Document soft-deleted', $id);

jsonResponse(['success' => true]);
