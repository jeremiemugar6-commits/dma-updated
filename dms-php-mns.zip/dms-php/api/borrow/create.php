<?php
require_once __DIR__ . '/../../includes/auth.php';
$session = requireAuthAPI('ADMIN');

$data = json_decode(file_get_contents('php://input'), true);
$db   = getDB();

$docId      = $data['document_id'] ?? null;
$borrowerId = $data['borrower_id'] ?? null;
if (!$docId || !$borrowerId) jsonResponse(['error' => 'document_id and borrower_id are required'], 400);

// Check document is ACTIVE
$stmt = $db->prepare("SELECT id, location FROM documents WHERE id = ? AND status = 'ACTIVE' AND is_deleted = 0");
$stmt->execute([$docId]);
$doc = $stmt->fetch();
if (!$doc) jsonResponse(['error' => 'Document is not available for borrowing'], 400);

$txId    = generateUUID();
$dueDate = $data['due_date'] ?? null;

$db->prepare("INSERT INTO borrow_transactions (id, document_id, borrower_id, due_date, status)
              VALUES (?, ?, ?, ?, 'ACTIVE')")->execute([$txId, $docId, $borrowerId, $dueDate ?: null]);

// Update document status to BORROWED
$db->prepare("UPDATE documents SET status = 'BORROWED' WHERE id = ?")->execute([$docId]);

logAudit($session['userId'], 'DOCUMENT_BORROWED', "Borrowed: {$doc['location']}", $docId);

jsonResponse(['success' => true, 'id' => $txId]);
