<?php
require_once __DIR__ . '/includes/auth.php';
$session = getSession();
if (!$session) {
    header('Location: /dms-php/login.php');
} elseif ($session['role'] === 'ADMIN') {
    header('Location: /dms-php/admin/storage.php');
} else {
    header('Location: /dms-php/profile.php');
}
exit;
