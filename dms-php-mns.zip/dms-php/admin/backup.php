<?php
require_once __DIR__ . '/../includes/auth.php';
$session             = requireAuth('ADMIN');
$session['fullname'] = $_COOKIE['dms_name'] ?? 'Admin';
$db                  = getDB();
$pageTitle           = 'Backup';
$activeNav           = 'backup';

$backupCount = (int)$db->query("SELECT COUNT(*) FROM documents WHERE backup_path IS NOT NULL AND is_deleted=0")->fetchColumn();
$totalCount  = (int)$db->query("SELECT COUNT(*) FROM documents WHERE is_deleted=0")->fetchColumn();

$stmt=$db->query("
    SELECT d.id,d.location,d.status,d.version,d.backup_path,d.created_at,
           u.fullname AS owner_name,dt.name AS type_name,
           (SELECT al.created_at FROM audit_logs al WHERE al.document_id=d.id AND al.action='DOCUMENT_BACKUP' ORDER BY al.created_at DESC LIMIT 1) AS last_backup
    FROM documents d
    JOIN users u ON u.id=d.owner_id
    JOIN document_types dt ON dt.id=d.document_type_id
    WHERE d.is_deleted=0 ORDER BY d.created_at DESC LIMIT 50");
$documents=$stmt->fetchAll();

include __DIR__ . '/../includes/layout.php';
?>
<div class="stats-grid" style="grid-template-columns:repeat(3,1fr)">
  <div class="stat-card"><div class="stat-icon blue"><?=icon('file')?></div><div><div class="stat-value"><?=$totalCount?></div><div class="stat-label">Total Documents</div></div></div>
  <div class="stat-card"><div class="stat-icon green"><?=icon('save')?></div><div><div class="stat-value"><?=$backupCount?></div><div class="stat-label">Backed Up</div></div></div>
  <div class="stat-card"><div class="stat-icon yellow"><?=icon('clock')?></div><div><div class="stat-value"><?=$totalCount-$backupCount?></div><div class="stat-label">Pending Backup</div></div></div>
</div>
<div class="card">
  <div class="card-header">
    <span class="card-title">Backup Management</span>
    <button class="btn btn-primary btn-sm" onclick="backupAll()"><?=icon('save')?> Backup All</button>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Document</th><th>Type</th><th>Owner</th><th>Status</th><th>Backup Status</th><th>Last Backup</th><th>Action</th></tr></thead>
      <tbody>
        <?php foreach($documents as $doc): ?>
        <tr>
          <td style="font-weight:500"><?=htmlspecialchars($doc['location'])?></td>
          <td><?=htmlspecialchars($doc['type_name'])?></td>
          <td><?=htmlspecialchars($doc['owner_name'])?></td>
          <td><span class="badge badge-<?=strtolower($doc['status'])?>"><?=ucfirst(strtolower($doc['status']))?></span></td>
          <td><?php if($doc['backup_path']): ?><span class="badge badge-active"><?=icon('check')?> Backed up</span><?php else: ?><span class="badge badge-pending">Not backed up</span><?php endif; ?></td>
          <td class="text-muted"><?=$doc['last_backup']?date('M d, Y H:i',strtotime($doc['last_backup'])):'—'?></td>
          <td><button class="btn btn-outline btn-sm" onclick="backupDoc('<?=$doc['id']?>')"><?=icon('save')?> Backup</button></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
$extraJs="const BASE='/dms-php';async function backupDoc(id){try{await apiFetch(BASE+'/api/documents/backup.php',{method:'POST',body:JSON.stringify({id})});showToast('Backed up','success');setTimeout(()=>location.reload(),800);}catch{}}async function backupAll(){if(!confirm('Back up all unbacked documents?'))return;try{const r=await apiFetch(BASE+'/api/documents/backup.php',{method:'POST',body:JSON.stringify({all:true})});showToast((r.count||0)+' documents backed up','success');setTimeout(()=>location.reload(),1000);}catch{}}";
include __DIR__ . '/../includes/layout_footer.php';
?>
