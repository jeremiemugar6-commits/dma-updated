<?php
// includes/layout.php
// Requires: $pageTitle, $activeNav, $session (with fullname, role)

if (!isset($pageTitle)) $pageTitle = 'Document Management';
if (!isset($activeNav)) $activeNav = '';
$isAdmin     = isset($session) && $session['role'] === 'ADMIN';
$displayName = $session['fullname'] ?? $_COOKIE['dms_name'] ?? 'User';
$BASE        = '/dms-php';

function icon(string $name): string {
    $icons = [
        'archive'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><rect x="2" y="3" width="20" height="4" rx="1"/><path d="M4 7v11a2 2 0 002 2h12a2 2 0 002-2V7M10 12h4"/></svg>',
        'eye'      => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
        'download' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
        'save'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>',
        'users'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>',
        'list'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>',
        'user'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
        'file'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>',
        'logout'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>',
        'plus'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
        'edit'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>',
        'trash'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/></svg>',
        'search'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
        'refresh'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg>',
        'check'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><polyline points="20 6 9 17 4 12"/></svg>',
        'x'        => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
        'clock'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
    ];
    return $icons[$name] ?? '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($pageTitle) ?> — MNS DMS</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= $BASE ?>/assets/css/style.css">
</head>
<body>

<div id="sidebar-overlay" onclick="document.querySelector('.sidebar').classList.remove('open');this.classList.remove('open')" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:99"></div>
<style>#sidebar-overlay.open{display:block!important}</style>

<div class="layout">
  <!-- SIDEBAR -->
  <aside class="sidebar">
    <div class="sidebar-logo">
      <img src="<?= $BASE ?>/assets/img/mns-logo.jpg" alt="MNS Logo" style="width:36px;height:36px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,0.3);">
      <span>MNS DMS</span>
    </div>

    <nav class="sidebar-nav">
      <?php if ($isAdmin): ?>
        <div class="sidebar-section-title">Management</div>
        <a href="<?= $BASE ?>/admin/storage.php"     class="sidebar-link <?= $activeNav==='storage'    ?'active':'' ?>"><?= icon('archive') ?> Storage</a>
        <a href="<?= $BASE ?>/admin/tracking.php"    class="sidebar-link <?= $activeNav==='tracking'   ?'active':'' ?>"><?= icon('eye') ?> Tracking</a>
        <a href="<?= $BASE ?>/admin/retrieval.php"   class="sidebar-link <?= $activeNav==='retrieval'  ?'active':'' ?>"><?= icon('download') ?> Retrieval</a>
        <a href="<?= $BASE ?>/admin/backup.php"      class="sidebar-link <?= $activeNav==='backup'     ?'active':'' ?>"><?= icon('save') ?> Backup</a>
        <div class="sidebar-section-title">Administration</div>
        <a href="<?= $BASE ?>/admin/users.php"       class="sidebar-link <?= $activeNav==='users'      ?'active':'' ?>"><?= icon('users') ?> Users</a>
        <a href="<?= $BASE ?>/admin/audit-trail.php" class="sidebar-link <?= $activeNav==='audit'      ?'active':'' ?>"><?= icon('list') ?> Audit Trail</a>
      <?php else: ?>
        <div class="sidebar-section-title">My Space</div>
        <a href="<?= $BASE ?>/profile.php"           class="sidebar-link <?= $activeNav==='profile'    ?'active':'' ?>"><?= icon('user') ?> Profile</a>
        <a href="<?= $BASE ?>/documents.php"         class="sidebar-link <?= $activeNav==='documents'  ?'active':'' ?>"><?= icon('file') ?> My Documents</a>
      <?php endif; ?>
    </nav>

    <div class="sidebar-footer">
      <div class="user-info">
        <div class="avatar"><?= strtoupper(substr($displayName, 0, 1)) ?></div>
        <div>
          <div style="color:#e2e8f0;font-weight:500;font-size:.82rem;line-height:1.3"><?= htmlspecialchars($displayName) ?></div>
          <div style="font-size:.72rem"><?= htmlspecialchars($session['role'] ?? '') ?></div>
        </div>
      </div>
      <a href="<?= $BASE ?>/api/auth/logout.php" class="sidebar-link" style="margin-top:4px;color:#f87171">
        <?= icon('logout') ?> Sign Out
      </a>
    </div>
  </aside>

  <!-- MAIN -->
  <div class="main-content">
    <header class="topbar">
      <div class="flex items-center gap-2">
        <button id="hamburger" class="hamburger" aria-label="Menu">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M3 12h18M3 6h18M3 18h18"/></svg>
        </button>
        <span class="topbar-title"><?= htmlspecialchars($pageTitle) ?></span>
      </div>
      <div class="topbar-actions">
        <div class="dropdown">
          <button class="btn btn-ghost btn-sm" data-dropdown>
            <div class="avatar" style="width:28px;height:28px;font-size:.7rem"><?= strtoupper(substr($displayName,0,1)) ?></div>
          </button>
          <div class="dropdown-menu">
            <?php if (!$isAdmin): ?>
            <a href="<?= $BASE ?>/profile.php" class="dropdown-item"><?= icon('user') ?> Profile</a>
            <?php endif; ?>
            <a href="<?= $BASE ?>/api/auth/logout.php" class="dropdown-item danger"><?= icon('logout') ?> Sign Out</a>
          </div>
        </div>
      </div>
    </header>

    <div class="page-body">
