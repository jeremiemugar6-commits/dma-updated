    </div><!-- /page-body -->
  </div><!-- /main-content -->
</div><!-- /layout -->

<div id="toast-container" class="toast-container"></div>
<script src="/dms-php/assets/js/main.js"></script>
<?php if (!empty($extraJs)): ?>
<script><?= $extraJs ?></script>
<?php endif; ?>
</body>
</html>
