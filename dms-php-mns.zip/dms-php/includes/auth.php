<?php
require_once __DIR__ . '/db.php';

define('SESSION_COOKIE_KEY', 'dms_session');
define('SESSION_SECRET',     'change-this-to-a-long-random-secret-key-2024');
define('SESSION_EXPIRY',      7 * 24 * 60 * 60);

function base64url_encode(string $data): string {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}
function base64url_decode(string $data): string {
    return base64_decode(strtr($data, '-_', '+/') . str_repeat('=', 3 - (3 + strlen($data)) % 4));
}
function createJWT(array $payload): string {
    $header     = base64url_encode(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
    $payload['iat'] = time();
    $payload['exp'] = time() + SESSION_EXPIRY;
    $payloadEnc = base64url_encode(json_encode($payload));
    $sig        = base64url_encode(hash_hmac('sha256', "$header.$payloadEnc", SESSION_SECRET, true));
    return "$header.$payloadEnc.$sig";
}
function verifyJWT(string $token): ?array {
    $parts = explode('.', $token);
    if (count($parts) !== 3) return null;
    [$header, $payload, $sig] = $parts;
    $expected = base64url_encode(hash_hmac('sha256', "$header.$payload", SESSION_SECRET, true));
    if (!hash_equals($expected, $sig)) return null;
    $data = json_decode(base64url_decode($payload), true);
    if (!$data || $data['exp'] < time()) return null;
    return $data;
}
function createSession(string $userId, string $role): void {
    $token = createJWT(['userId' => $userId, 'role' => $role]);
    setcookie(SESSION_COOKIE_KEY, $token, [
        'expires'  => time() + SESSION_EXPIRY,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}
function deleteSession(): void {
    setcookie(SESSION_COOKIE_KEY, '', ['expires' => time() - 3600, 'path' => '/']);
    unset($_COOKIE[SESSION_COOKIE_KEY]);
}
function getSession(): ?array {
    $token = $_COOKIE[SESSION_COOKIE_KEY] ?? null;
    if (!$token) return null;
    return verifyJWT($token);
}
function requireAuth(?string $requiredRole = null): array {
    $session = getSession();
    if (!$session) {
        header('Location: /dms-php/login.php');
        exit;
    }
    if ($requiredRole && $session['role'] !== $requiredRole) {
        $dest = ($session['role'] === 'ADMIN') ? '/dms-php/admin/storage.php' : '/dms-php/profile.php';
        header('Location: ' . $dest);
        exit;
    }
    return $session;
}
function requireAuthAPI(?string $requiredRole = null): array {
    $session = getSession();
    if (!$session) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Unauthorized']);
        exit;
    }
    if ($requiredRole && $session['role'] !== $requiredRole) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Forbidden']);
        exit;
    }
    return $session;
}
function logAudit(string $userId, string $action, string $details = '', ?string $documentId = null): void {
    try {
        $db   = getDB();
        $ip   = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $id   = generateUUID();
        $stmt = $db->prepare(
            "INSERT INTO audit_logs (id, action, details, ip_address, user_id, document_id)
             VALUES (?, ?, ?, ?, ?, ?)"
        );
        $stmt->execute([$id, $action, $details, $ip, $userId, $documentId]);
    } catch (Exception $e) {}
}
function generateUUID(): string {
    return sprintf(
        '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}
function jsonResponse(mixed $data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}
